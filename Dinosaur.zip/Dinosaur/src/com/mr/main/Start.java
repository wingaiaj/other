package com.mr.main;

import com.mr.service.ScoreRecorder;
import com.mr.view.MainFrame;

/**
 * @ClassName Start
 * @Description TODO
 * @Author xpower
 * @Date 2022/3/24 10:39
 * @Version 1.0
 */
public class Start{
    public static void main(String[] args) {
            MainFrame mainFrame=new MainFrame();
            mainFrame.setVisible(true);

    }
}
