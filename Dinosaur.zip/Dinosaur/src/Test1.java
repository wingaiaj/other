import jdk.jfr.StackTrace;
import org.junit.Test;
import com.mr.modle.*;
import java.awt.*;

/**
 * @ClassName Test
 * @Description TODO
 * @Author xpower
 * @Date 2022/4/12 19:56
 * @Version 1.0
 */
public class Test1 {
    @Test
    public void TestGetHeight(){
        Obstacle o=new Obstacle();
        System.out.println(o.image.getWidth());
    }

}
